![alt text](https://ineuron.ai/images/ineuron-logo.png)

# Unicorn companies Analysis
## Assignment

1. Take the Same Dataset and analyze the following.

        a. Make a visual showing Top five cities with most unicorn companies.
        b. Make a map showing valuation by Country.
        c. Draw a visual which shows top 10 investors of Unicorn Companies. Also, show the no. of companies invested as data label.
        d. A card showing total no. of Investors.
        e. Make a visual which shows valuation based on industry.
        
        