
![alt text](https://ineuron.ai/images/ineuron-logo.png)

# Indian 

## Formatting

| Format             | Details                                                       |
 ------------------ | -------------------------------------------------------------|
 Background Color (Visual) |#FFFFFF, #2A5215, #F7F3EC, #65BAFF, #7D1C1A |
 Background Color (Title) |##FFFFFF |
 Visualization Colors |#7D1C1A, #2A5215, #311818, #F7F3EC, #563807, #235A7A, #E6E6E6, #99C9F8 |
 Font Color |#000000|
 Font |Segoe UI|
 Font Size (visualizations)|10 |
 Font Size (visualizations Title)| 12  |
 Font Size ( cards)| 18 or 16,11|
Font size (table title) |12|
Font size (table values) |12,10|
Font size (slicer title) |18|
Font size (slicer) |11|
Font Size (Title) |20 |
Font (Title) |Segoe UI| 