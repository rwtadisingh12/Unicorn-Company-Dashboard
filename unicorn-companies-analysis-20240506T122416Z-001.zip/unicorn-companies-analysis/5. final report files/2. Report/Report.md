![alt text](https://ineuron.ai/images/ineuron-logo.png)

# Unicorn companies Analysis : 

## Conclusion

The Observations From the dashboard are :

1. The highest number of unicorn companies are in United States.
2. Artificial Intelligence Industry has the highest valuation.
3. Among all the continents, North America has the highest number of unicorn companies.
4. The company Bytedance has the highest valuation.
5. Incidentally, 2021 was a windfall for many startups. Almost half (48%) of the unicorns reached that status in 2021. This is largely the impact of covid pandemic and the WFH order.
